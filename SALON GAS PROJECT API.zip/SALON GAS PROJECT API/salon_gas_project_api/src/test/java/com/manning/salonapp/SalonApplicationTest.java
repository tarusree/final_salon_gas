package com.manning.salonapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalonApplicationTest {

    @Test
    void contextLoads() {
        //add assertions
    }

    /*Add remaining tests here*/
}
