package com.manning.salonapp.slot;

public enum SlotStatus {
    AVAILABLE, LOCKED, CONFIRMED, CANCELLED
}
