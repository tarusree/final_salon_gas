package com.manning.salonapp.payment.models;

public enum PaymentStatus {
    SUCCESS, FAILED,PROCESSING
}
