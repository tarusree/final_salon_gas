package com.manning.salonapp.ticket;

/* Ticket Status */
public enum TicketStatus {
    BOOKED, ARRIVED, NOT_ARRIVED
}
