package com.manning.salonapp.common;

/* Salon Exception */
public class SalonException extends RuntimeException {
    public SalonException(String detail) {
        super(detail);
    }
}
