import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import LoadingIndicatorComponent from "./common/loader/loading-indicator-component";
import AppNotificationComponent from "./common/notification/app-notification-component";
import ChooseService from "./choose-service-slot/ChooseService";
import { Route, Routes } from "react-router-dom";
import ChooseSlot from "./choose-service-slot/ChooseSlot";
import { BrowserRouter as Router } from "react-router-dom";
import MakePaymentContainer from "./payment/PaymentContainer";

import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";

const stripePromise = loadStripe("pk_test_A7jK4iCYHL045qgjjfzAfPxu");

const App = () => {
  return (
    <Router>
      <div>
        <LoadingIndicatorComponent />
        <nav className="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
          <a className="navbar-brand" href="/">SALON (Smart Automated LPG Online Network)</a>
        </nav>
        <main role="main" className="container">
          <div className="padding-container">

            <Routes>
              <Route path="/" element={<ChooseService />} />
              <Route path="/chooseslot/:serviceId/:serviceName" element={<ChooseSlot />} />
              <Route path="/makepayment/:slotId/:serviceId/:serviceName" element={
                <Elements stripe={stripePromise}>
                  <MakePaymentContainer />
                </Elements>
              } />
              <Route path="*" element={<ChooseService />} />
            </Routes>

          </div>
        </main>
        <AppNotificationComponent />
      </div>
    </Router>
  );
}

export default App;
